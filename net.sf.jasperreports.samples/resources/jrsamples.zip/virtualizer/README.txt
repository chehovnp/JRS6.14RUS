In order to properly setup the virtualizer details the user can use the file level preferences settings.
Give a look at the screenshot "virtualizerSettings.png".
The ouput sample of a report preview is shown in the screenshot "virtualizerOutput.png".