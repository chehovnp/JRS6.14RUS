You need to use the left panel in the preview mode in order to set the proper parameter settings.
Example of settings for the "Report Parameters" panel tab.
- Report Locale => English (United States)
- net.sf.jasperreports.json.date.pattern => yyyy-MM-dd
- net.sf.jasperreports.json.number.patter => #,##0.##
- JSON_LOCALE => English
This information is set via Java code in the original JasperReports sample. 