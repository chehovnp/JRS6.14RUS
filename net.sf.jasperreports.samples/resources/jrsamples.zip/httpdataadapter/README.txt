You will need to deploy the web application into a dedicated container (i.e Tomcat, Jetty).
If needed fix the URL of the data adapters.